GOOGLE_SUGGEST_CLASS = "F9PbJd"
GOOGLE_THUBNAILS_XPATH = '//img[contains(@class, "rg_i")]'
GOOGLE_IMAGE_LOADING_BAR_XPATH = '//*/div[contains(@class, "tvh9oe")][2]//div[@class="k7O2sd"]'
GOOGLE_IMAGE_FULLSIZE_XPATH = '//*/div[contains(@class, "tvh9oe")][2]//img[contains(@class, "n3VNCb")]'
